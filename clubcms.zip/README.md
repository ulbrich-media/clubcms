[![Build public assets](https://github.com/ulbrich-media/clubcms/actions/workflows/build.yaml/badge.svg)](https://github.com/ulbrich-media/clubcms/actions/workflows/build.yaml)
[![Publish to TER](https://github.com/ulbrich-media/clubcms/actions/workflows/publish-ter.yaml/badge.svg)](https://github.com/ulbrich-media/clubcms/actions/workflows/publish-ter.yaml)

# ClubCMS
A TYPO3 CMS based website template, made for clubs and smaller non-profit organisations.
